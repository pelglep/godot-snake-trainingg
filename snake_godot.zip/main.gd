extends Node2D

@onready var timer = $Timer
@onready var snake = $board/SnakeHead
@onready var food = $board/food
@onready var snakeBody = $board/SnakeBody
@onready var score = $CanvasLayer/score
@onready var GameOver = $CanvasLayer/GameOver
@onready var _snake = preload("res://snake_body_segment.tscn")
@onready var wall_layer = $WallLayer
@onready var wall_tile = preload("res://wall_tile.tscn")
@onready var floor_layer = $board/FloorLayer
@onready var floor_tile = preload("res://floor_tile.tscn")
@onready var snake_head_sprite = $board/SnakeHead/Sprite2D
@onready var head_up = preload("res://asset/snake_asset/head/head_turn_up.png")
@onready var head_down = preload("res://asset/snake_asset/head/head_turn_down.png")
@onready var head_left = preload("res://asset/snake_asset/head/head_turn_left.png")
@onready var head_right = preload("res://asset/snake_asset/head/head_turn_right.png")

var case_size = 32
var direction = Vector2(1, 0)
var next_direction = Vector2(1, 0)
var snake_length = 1
var snake_positions = []
var game_is_over = false
var _score = 0


func _ready():
	generate_walls()
	generate_floor()



func _process(delta):
	if Input.is_action_just_pressed("up") && direction != Vector2(0, 1):
		next_direction = Vector2(0, -1)
	elif Input.is_action_just_pressed("down") && direction != Vector2(0, -1):
		next_direction = Vector2(0, 1)
	elif Input.is_action_just_pressed("left") && direction != Vector2(1, 0):
		next_direction = Vector2(-1, 0)
	elif Input.is_action_just_pressed("right") && direction != Vector2(-1, 0):
		next_direction = Vector2(1, 0)
	if game_is_over == true && Input.is_action_just_pressed("restart"):
		timer.start()
		game_is_over = false
		GameOver.text = ""
		_score = 0
		score.text = "SCORE  " + str(_score).pad_zeros(3)

func _on_timer_timeout():
	direction = next_direction
	update_head_sprite()
	snake.position += direction * case_size
	snake_positions.push_front(snake.position)

	if snake.position.x < 0 || snake.position.x >= 640 || snake.position.y < 0 || snake.position.y >= 640 :
		game_over()
		return

	if food.position == snake.position:
		snake_length += 1
		spawn_food()
		_score += 1
		score.text = "SCORE  " + str(_score).pad_zeros(3)


	if snake_positions.size() > snake_length:
		snake_positions.pop_back()
		
	for i in range(snake_positions.size()):
		if i > 0:
			if snake_positions[i] == snake_positions[0]:
				game_over()
				return
	draw_snake()

func draw_snake():
	for child in snakeBody.get_children():
		child.queue_free()

	for i in range(snake_positions.size()):
		if i > 0:
			var segment = _snake.instantiate()
			segment.position = snake_positions[i]
			snakeBody.add_child(segment)

func game_over():
		snake.position = Vector2(320.0, 320.0)
		direction = Vector2(1.0, 0.0)
		next_direction = Vector2(1.0, 0.0)
		snake_length = 1
		snake_positions = []
		spawn_food()
		draw_snake()
		timer.stop()
		direction = Vector2(1.0, 0.0)
		next_direction = Vector2(1.0, 0.0)
		update_head_sprite()
		game_is_over = true
		GameOver.text = "Game Over - Appuie sur Espace pour recommencer"

func spawn_food():
	var new_food_position = Vector2(randi_range(0, 19) * case_size, randi_range(0, 19) * case_size)

	while snake_positions.has(new_food_position):
		new_food_position = Vector2(randi_range(0, 19) * case_size, randi_range(0, 19) * case_size)

	food.position = new_food_position

func create_wall_tile(grid_x, grid_y, rotation):
	var wall = wall_tile.instantiate()
	wall.position = Vector2(
		grid_x * case_size + case_size / 2,
		grid_y * case_size + case_size / 2
	)
	wall.rotation_degrees = rotation
	wall_layer.add_child(wall)

func generate_walls():
	for x in range(22):
		create_wall_tile(x, 0, 0) # mur du haut
		create_wall_tile(x, 21, 180) # mur du bas

	for y in range(1, 21):
		create_wall_tile(0, y, -90) # mur gauche
		create_wall_tile(21, y, 90) # mur droit

func generate_floor():
	for x in range(20):
		for y in range(20):
			var tile = floor_tile.instantiate()
			tile.position = Vector2(x * case_size, y * case_size)
			floor_layer.add_child(tile)

func update_head_sprite():
	if direction == Vector2(0, -1):
		snake_head_sprite.texture = head_up
	elif direction == Vector2(0, 1):
		snake_head_sprite.texture = head_down
	elif direction == Vector2(-1, 0):
		snake_head_sprite.texture = head_left
	elif direction == Vector2(1, 0):
		snake_head_sprite.texture = head_right
